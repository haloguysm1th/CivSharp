# CivSharp
A simple civlike game written in C# using RLNet, as well as RogueSharp.


